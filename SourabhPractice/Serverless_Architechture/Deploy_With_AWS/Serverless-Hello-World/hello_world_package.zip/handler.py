from __future__ import print_function

print("Loading Function")

def lambda_handler(event, context):
	return "Hello World! Response By Lambda Function"
